'use client';
import { motion } from 'framer-motion';
import Image from 'next/image';

export default function Avatar() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className="avatar-container"
    >
      <motion.div
        className="avatar-wrapper"
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
        whileHover={{ scale: 1.05 }}
      >
        <div className="avatar-ring">
          <Image
            src="/avatar.jpg"
            alt="Quesz Avatar"
            width={140}
            height={140}
            className="avatar-image"
            priority
          />
        </div>
        <div className="avatar-shadow" />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <h1 className="hero-name">Quesz</h1>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.6 }}
      >
        <p className="hero-tagline">Linux · Anime · Games · Pixel Art</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7, duration: 0.6 }}
        className="status-badge"
      >
        <span className="status-text">aka Baka</span>
        <span className="status-dot" />
        <span className="status-text">he/him</span>
      </motion.div>
    </motion.div>
  );
}
