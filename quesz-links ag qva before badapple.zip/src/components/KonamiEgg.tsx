'use client';
import { useKonamiCode } from '@/hooks/useKonamiCode';
import { motion, AnimatePresence } from 'framer-motion';

export default function KonamiEgg() {
  const { activated, progress } = useKonamiCode();

  return (
    <>
      {/* Progress indicator — subtle hint in corner */}
      {progress > 0 && !activated && (
        <div className="konami-progress">
          <div className="konami-progress-bar" style={{ width: `${progress * 100}%` }} />
        </div>
      )}

      {/* Full-screen easter egg */}
      <AnimatePresence>
        {activated && (
          <motion.div
            className="konami-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Flash effect */}
            <motion.div
              className="konami-flash"
              initial={{ opacity: 1 }}
              animate={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            />

            {/* Rainbow background */}
            <div className="konami-rainbow" />

            {/* CRT power-on lines */}
            <motion.div
              className="konami-powerline"
              initial={{ scaleY: 0.002, scaleX: 1.5 }}
              animate={{ scaleY: 1, scaleX: 1 }}
              transition={{ duration: 0.4, ease: 'easeOut' }}
            />

            {/* Hidden message */}
            <motion.div
              className="konami-message"
              initial={{ scale: 0, rotate: -10 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.4, type: 'spring', stiffness: 200 }}
            >
              <div className="konami-title">KONAMI CODE ACTIVATED!</div>
              <div className="konami-subtitle">You found the secret!</div>
              <div className="konami-hint">
                ↑ ↑ ↓ ↓ ← → ← → B A
              </div>
              <div className="konami-ascii">
                {`
  ╔══════════════════════════╗
  ║   ★ PLAYER 1 READY ★    ║
  ║                          ║
  ║   30 EXTRA LIVES ADDED   ║
  ║   (not really lol)       ║
  ║                          ║
  ║   ♫ Keep exploring! ♫    ║
  ╚══════════════════════════╝
                `}
              </div>
              <motion.div
                className="konami-sparkles"
                animate={{ rotate: 360 }}
                transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
              >
                ✨🌟💫⭐✨🌟💫⭐
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
