'use client';
import { motion } from 'framer-motion';

export default function Footer() {
  return (
    <motion.footer
      className="footer"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 2.5, duration: 0.8 }}
    >
      <div className="footer-content">
        <p className="footer-text">
          Made with <span className="footer-heart">♥</span> by Quesz
        </p>
        <p className="footer-hint">
          Try the Konami Code... ↑ ↑ ↓ ↓ ← → ← → B A
        </p>
      </div>
    </motion.footer>
  );
}
