'use client';
import { useEffect, useRef, useCallback } from 'react';
import { useMousePosition } from '@/hooks/useMousePosition';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  baseOpacity: number;
  twinkleSpeed: number;
  twinklePhase: number;
  color: string;
}

interface ShootingStar {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
}

const COLORS = ['#8b7ec8', '#e85d75', '#4ecdc4', '#f0ece2', '#c9a0dc'];

export default function Background() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { position, normalized } = useMousePosition();
  const mouseRef = useRef({ x: 0, y: 0, nx: 0.5, ny: 0.5 });
  const particlesRef = useRef<Particle[]>([]);
  const shootingStarsRef = useRef<ShootingStar[]>([]);
  const animFrameRef = useRef<number>(0);

  useEffect(() => {
    mouseRef.current = { x: position.x, y: position.y, nx: normalized.x, ny: normalized.y };
  }, [position, normalized]);

  const initParticles = useCallback((width: number, height: number) => {
    const count = Math.floor((width * height) / 8000);
    const particles: Particle[] = [];
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.15,
        vy: (Math.random() - 0.5) * 0.15,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.6 + 0.2,
        baseOpacity: Math.random() * 0.6 + 0.2,
        twinkleSpeed: Math.random() * 0.02 + 0.005,
        twinklePhase: Math.random() * Math.PI * 2,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
      });
    }
    return particles;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      particlesRef.current = initParticles(canvas.width, canvas.height);
    };
    resize();
    window.addEventListener('resize', resize);

    let time = 0;
    const animate = () => {
      time++;
      const { width, height } = canvas;
      const mouse = mouseRef.current;

      ctx.clearRect(0, 0, width, height);

      // Draw subtle grid
      ctx.strokeStyle = 'rgba(139, 126, 200, 0.03)';
      ctx.lineWidth = 0.5;
      const gridSize = 60;
      const offsetX = (mouse.nx - 0.5) * 20;
      const offsetY = (mouse.ny - 0.5) * 20;
      for (let x = 0; x < width + gridSize; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x + offsetX, 0);
        ctx.lineTo(x + offsetX, height);
        ctx.stroke();
      }
      for (let y = 0; y < height + gridSize; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y + offsetY);
        ctx.lineTo(width, y + offsetY);
        ctx.stroke();
      }

      // Update and draw particles
      for (const p of particlesRef.current) {
        // Parallax based on cursor
        const parallaxX = (mouse.nx - 0.5) * p.size * 8;
        const parallaxY = (mouse.ny - 0.5) * p.size * 8;

        // Cursor proximity acceleration
        const dx = mouse.x - (p.x + parallaxX);
        const dy = mouse.y - (p.y + parallaxY);
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 200 && dist > 0) {
          const force = (200 - dist) / 200 * 0.003;
          p.vx += dx * force * 0.1;
          p.vy += dy * force * 0.1;
        }

        p.x += p.vx;
        p.y += p.vy;

        // Dampen velocity
        p.vx *= 0.999;
        p.vy *= 0.999;

        // Wrap around
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;
        if (p.y < -10) p.y = height + 10;
        if (p.y > height + 10) p.y = -10;

        // Twinkle
        p.opacity = p.baseOpacity + Math.sin(time * p.twinkleSpeed + p.twinklePhase) * 0.3;

        const drawX = p.x + parallaxX;
        const drawY = p.y + parallaxY;

        ctx.beginPath();
        ctx.arc(drawX, drawY, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0, Math.min(1, p.opacity));
        ctx.fill();

        // Glow for larger particles
        if (p.size > 1.5) {
          ctx.beginPath();
          ctx.arc(drawX, drawY, p.size * 3, 0, Math.PI * 2);
          const grd = ctx.createRadialGradient(drawX, drawY, 0, drawX, drawY, p.size * 3);
          grd.addColorStop(0, p.color);
          grd.addColorStop(1, 'transparent');
          ctx.fillStyle = grd;
          ctx.globalAlpha = p.opacity * 0.15;
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;

      // Shooting stars
      if (Math.random() < 0.003) {
        shootingStarsRef.current.push({
          x: Math.random() * width,
          y: Math.random() * height * 0.3,
          vx: (Math.random() * 4 + 3) * (Math.random() > 0.5 ? 1 : -1),
          vy: Math.random() * 2 + 1,
          life: 0,
          maxLife: 40 + Math.random() * 30,
          size: Math.random() * 1.5 + 0.5,
        });
      }

      shootingStarsRef.current = shootingStarsRef.current.filter(star => {
        star.x += star.vx;
        star.y += star.vy;
        star.life++;

        const progress = star.life / star.maxLife;
        const alpha = progress < 0.1 ? progress * 10 : 1 - (progress - 0.1) / 0.9;

        ctx.beginPath();
        ctx.moveTo(star.x, star.y);
        ctx.lineTo(star.x - star.vx * 8, star.y - star.vy * 8);
        ctx.strokeStyle = `rgba(240, 236, 226, ${alpha * 0.7})`;
        ctx.lineWidth = star.size;
        ctx.stroke();

        return star.life < star.maxLife;
      });

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [initParticles]);

  return (
    <>
      <canvas
        ref={canvasRef}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          zIndex: 0,
          pointerEvents: 'none',
        }}
      />
      {/* Noise overlay */}
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          zIndex: 0,
          pointerEvents: 'none',
          opacity: 0.035,
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />
    </>
  );
}
