'use client';
import { useEffect, useRef, useState, useCallback } from 'react';

type CatDirection = 'right' | 'left';

interface HeartParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  size: number;
}

const RAINBOW_COLORS = [
  '#ff0000', // Red
  '#ff9900', // Orange
  '#ffff00', // Yellow
  '#33ff00', // Green
  '#0099ff', // Blue
  '#6633ff', // Purple
];

export default function PixelCat() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [posX, setPosX] = useState(100);
  const [direction, setDirection] = useState<CatDirection>('right');
  const [hearts, setHearts] = useState<HeartParticle[]>([]);
  const posXRef = useRef(posX);
  const dirRef = useRef(direction);
  const tickRef = useRef(0);

  useEffect(() => {
    posXRef.current = posX;
  }, [posX]);
  useEffect(() => {
    dirRef.current = direction;
  }, [direction]);

  const pet = useCallback(() => {
    const newHearts: HeartParticle[] = [];
    for (let i = 0; i < 8; i++) {
      newHearts.push({
        x: posXRef.current + 45,
        y: window.innerHeight - 70,
        vx: (Math.random() - 0.5) * 4,
        vy: -(Math.random() * 4 + 2),
        life: 50,
        size: Math.random() * 10 + 6,
      });
    }
    setHearts((prev) => [...prev, ...newHearts]);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = 140;
    };
    resize();
    window.addEventListener('resize', resize);

    const catWidth = 90;

    const tick = () => {
      tickRef.current++;

      // Update position and bounce off walls
      setPosX((prev) => {
        let next = prev;
        if (dirRef.current === 'right') {
          next += 2.2;
          if (next > window.innerWidth - catWidth - 20) {
            setDirection('left');
          }
        } else {
          next -= 2.2;
          if (next < 20) {
            setDirection('right');
          }
        }
        return next;
      });

      // Clear Canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const currentPosX = posXRef.current;
      const currentDir = dirRef.current;

      const bobY = Math.sin(tickRef.current * 0.15) * 5;
      const trailBaseY = 40 + bobY;

      // Draw Rainbow Trail
      const trailWidth = 8;
      const waveAmplitude = 5;
      const waveFreq = 0.04;
      const bandHeight = 7;

      if (currentDir === 'right') {
        for (let x = 0; x < currentPosX + 10; x += trailWidth) {
          const waveY = Math.sin((x - tickRef.current * 5) * waveFreq) * waveAmplitude;
          RAINBOW_COLORS.forEach((color, i) => {
            ctx.fillStyle = color;
            ctx.fillRect(x, trailBaseY + i * bandHeight + waveY, trailWidth, bandHeight);
          });
        }
      } else {
        for (let x = window.innerWidth; x > currentPosX + catWidth - 10; x -= trailWidth) {
          const waveY = Math.sin((x + tickRef.current * 5) * waveFreq) * waveAmplitude;
          RAINBOW_COLORS.forEach((color, i) => {
            ctx.fillStyle = color;
            ctx.fillRect(x - trailWidth, trailBaseY + i * bandHeight + waveY, trailWidth, bandHeight);
          });
        }
      }

      // Update heart particles
      setHearts((prev) =>
        prev
          .map((h) => ({ ...h, x: h.x + h.vx, y: h.y + h.vy, vy: h.vy + 0.08, life: h.life - 1 }))
          .filter((h) => h.life > 0)
      );
    };

    const animInterval = setInterval(tick, 1000 / 60);

    return () => {
      window.removeEventListener('resize', resize);
      clearInterval(animInterval);
    };
  }, []);

  const bobY = Math.sin(tickRef.current * 0.15) * 5;

  return (
    <>
      {/* Canvas for rendering rainbow trail */}
      <canvas
        ref={canvasRef}
        style={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          width: '100%',
          height: 140,
          zIndex: 49,
          pointerEvents: 'none',
        }}
      />

      {/* Official animated Nyan Cat SVG */}
      <div
        onClick={pet}
        style={{
          position: 'fixed',
          bottom: 30 + bobY,
          left: posX,
          width: 90,
          height: 60,
          zIndex: 50,
          cursor: 'pointer',
          transform: direction === 'left' ? 'scaleX(-1)' : 'none',
          transition: 'transform 0.2s ease',
        }}
        title="Nyan Cat! Click to pet!"
      >
        <img
          src="/nyancat.svg"
          alt="Nyan Cat"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'contain',
          }}
        />
      </div>

      {/* Heart particles */}
      {hearts.map((h, i) => (
        <div
          key={`heart-${i}-${h.life}`}
          style={{
            position: 'fixed',
            left: h.x,
            top: h.y,
            fontSize: h.size,
            opacity: h.life / 50,
            pointerEvents: 'none',
            zIndex: 51,
            transition: 'none',
          }}
        >
          💜
        </div>
      ))}
    </>
  );
}
