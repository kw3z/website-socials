'use client';
import SocialCard from './SocialCard';
import { socials } from '@/data/socials';
import { motion } from 'framer-motion';

export default function SocialGrid() {
  // Separate projects and main socials
  const projectIds = ['tmtbl', 'cursor-pack', 'dotfiles'];
  const projects = socials.filter((s) => projectIds.includes(s.id));
  const mainSocials = socials.filter((s) => !projectIds.includes(s.id));

  // Explicit visual order for the bento grid
  const socialOrder = [
    'anilist', 'discord', 'github', 'spotify',
    'steam', 'instagram', 'youtube', 'riot',
    'fluxer', 'email',
  ];
  const sortedSocials = socialOrder
    .map((id) => mainSocials.find((s) => s.id === id))
    .filter(Boolean) as typeof mainSocials;

  return (
    <div className="layout-wrapper">
      {/* Bento Grid for Socials */}
      <section className="section-container">
        <h2 className="section-title">Socials</h2>
        <div className="bento-grid">
          {sortedSocials.map((social, i) => (
            <div key={social.id} className="bento-item" data-id={social.id}>
              <SocialCard social={social} index={i} />
            </div>
          ))}
        </div>
      </section>

      {/* Projects Section */}
      <section className="section-container projects-section">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.6 }}
        >
          <h2 className="section-title">Featured Projects</h2>
        </motion.div>
        <div className="projects-grid">
          {projects.map((project, i) => (
            <div key={project.id} className="project-item">
              <SocialCard social={project} index={i + mainSocials.length} />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
