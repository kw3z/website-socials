'use client';
import { useState, useEffect, useCallback } from 'react';

const KONAMI_CODE = [
  'ArrowUp', 'ArrowUp',
  'ArrowDown', 'ArrowDown',
  'ArrowLeft', 'ArrowRight',
  'ArrowLeft', 'ArrowRight',
  'KeyB', 'KeyA',
];

export function useKonamiCode() {
  const [activated, setActivated] = useState(false);
  const [progress, setProgress] = useState(0);

  const reset = useCallback(() => {
    setActivated(false);
  }, []);

  useEffect(() => {
    let index = 0;
    let timeout: ReturnType<typeof setTimeout>;

    const handler = (e: KeyboardEvent) => {
      if (activated) return;

      if (e.code === KONAMI_CODE[index]) {
        index++;
        setProgress(index / KONAMI_CODE.length);

        clearTimeout(timeout);
        timeout = setTimeout(() => {
          index = 0;
          setProgress(0);
        }, 3000);

        if (index === KONAMI_CODE.length) {
          setActivated(true);
          setProgress(1);
          index = 0;

          // Auto-reset after 12 seconds
          setTimeout(() => {
            setActivated(false);
            setProgress(0);
          }, 12000);
        }
      } else {
        index = 0;
        setProgress(0);
      }
    };

    window.addEventListener('keydown', handler);
    return () => {
      window.removeEventListener('keydown', handler);
      clearTimeout(timeout);
    };
  }, [activated]);

  return { activated, progress, reset };
}
